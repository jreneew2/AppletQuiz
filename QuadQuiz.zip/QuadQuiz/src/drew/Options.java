package drew;

import java.awt.event.MouseListener;

import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;

public class Options extends JPanel
			 implements MouseListener {
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 3701573579935678995L;
	
	Font myFont = new Font("Serif", Font.BOLD | Font.ITALIC, 20);
	GridLayout myLayout = new GridLayout(4,4);
    int HALF_WIDTH = getWidth() / 2;
    int HALF_HEIGHT = getHeight() / 2;

    public void init() {
    	addMouseListener(this);
    	this.setLayout(myLayout);
    }

    public void start() {
    }
    
    public void stop() {
    }

    public void destroy() {
    }

    public void paint(Graphics g) {
    }

   
    public void mouseEntered(MouseEvent event) {
    }
    public void mouseExited(MouseEvent event) {
    }
    public void mousePressed(MouseEvent event) {
    }
    public void mouseReleased(MouseEvent event) {
    }

    public void mouseClicked(MouseEvent event) {
    }
}