package drew;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JApplet;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

public class Main extends JApplet{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6568278275823927953L;
	
	public void init() {
		try {
			SwingUtilities.invokeAndWait(new Runnable() {
				public void run() {
					createGUI();
				}
			});
		} catch(Exception e) {
			System.err.println("createGUI did not complete!");
		}
	}
	
	private void createGUI() {
		this.setLayout(new GridLayout(2,1));
		//Quiz myQuiz = new Quiz();
		Options myOption = new Options();
		
		JLabel[] answers = new JLabel[16];
	    for(int i = 0; i < 16; i++)
	    {
	    	answers[i] = new JLabel();
	    	answers[i].setText("HI!");
	    	answers[i].setOpaque(true);
	    	myOption.add(answers[i]);
	    }
		//myQuiz.setOpaque(true);
		myOption.setOpaque(true);
		//this.add(myQuiz);
		this.add(myOption);
	}
}
